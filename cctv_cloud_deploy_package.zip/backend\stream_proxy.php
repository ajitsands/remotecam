<?php
/**
 * SanDS Lab CCTV Cloud - HTTPS Stream Relay & WHEP WebRTC Proxy
 * Bridges MediaMTX (127.0.0.1:8889 / 8888) to Browser over Pure HTTPS
 */

require_once __DIR__ . '/config.php';

$action = $_GET['action'] ?? '';
$stream = preg_replace('/[^a-zA-Z0-9_\/-]/', '', $_GET['stream'] ?? 'camera1');

// 1. WHEP WebRTC SDP Signaling Proxy (Enables 100% HTTPS WebRTC playback)
if ($action === 'whep') {
    $sdpOffer = file_get_contents('php://input');
    
    $ch = curl_init("http://127.0.0.1:8889/live/{$stream}/whep");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $sdpOffer);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/sdp',
        'User-Agent: SanDS-CCTV-Proxy/1.0'
    ]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);

    $answerSdp = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode >= 200 && $httpCode < 300) {
        header('Content-Type: application/sdp');
        http_response_code(200);
        echo $answerSdp;
        exit;
    }

    sendJsonResponse(['status' => 'error', 'message' => 'Camera stream offline or WHEP not ready', 'code' => $httpCode], 502);
}

// 2. HLS Playlist & Video Chunk Proxy (.m3u8 / .ts)
if ($action === 'hls') {
    $file = $_GET['file'] ?? "live/{$stream}/index.m3u8";
    $file = preg_replace('/[^a-zA-Z0-9_\/.-]/', '', $file);

    $ch = curl_init("http://127.0.0.1:8888/{$file}");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
    $content = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    curl_close($ch);

    if ($httpCode === 200) {
        if (strpos($file, '.m3u8') !== false) {
            header('Content-Type: application/vnd.apple.mpegurl');
            // Rewrite segment paths to proxy through stream_proxy.php
            $content = preg_replace('/(segment_.*\.ts)/', 'stream_proxy.php?action=hls&file=live/' . $stream . '/$1', $content);
        } elseif (strpos($file, '.ts') !== false) {
            header('Content-Type: video/mp2t');
        }
        echo $content;
        exit;
    }

    sendJsonResponse(['status' => 'error', 'message' => 'HLS stream not found'], 404);
}

sendJsonResponse(['status' => 'error', 'message' => 'Invalid stream action'], 400);
